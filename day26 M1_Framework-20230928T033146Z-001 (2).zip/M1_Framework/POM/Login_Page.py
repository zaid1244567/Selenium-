from Generic.Reading_Json import *

loc = read_json_locator()

class LoginPage:
    def __init__(self, driver):
        self.driver = driver
    def username(self, data):
        self.driver.find_element(loc["username"][0], loc["username"][1]).send_keys(data)
    def password(self, data):
        self.driver.find_element(loc["password"][0], loc["password"][1]).send_keys(data)
    def login_button(self):
        self.driver.find_element(loc["login_button"][0], loc["login_button"][1]).click()
