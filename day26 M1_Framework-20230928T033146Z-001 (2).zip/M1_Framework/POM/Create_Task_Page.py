from selenium.webdriver.support.select import Select
from Generic.Read_excel import *

loc = read_locator("Create_Task_Page")

class CreateTaskPage:
    def __init__(self, driver):
        self.driver = driver
    def select_customer(self):
        dd = self.driver.find_element("name", "customerId")
        s = Select(dd)
        s.select_by_visible_text("-- new customer --")
    def customer_name(self, data):
        self.driver.find_element(loc["customer_name"][0], loc["customer_name"][1]).send_keys(data)
    def project_name(self, data):
        self.driver.find_element(loc["project_name"][0], loc["project_name"][1]).send_keys(data)
    def task_name(self, data):
        self.driver.find_element(loc["task_name"][0], loc["task_name"][1]).send_keys(data)
    def createtask_button(self):
        self.driver.find_element(loc["createtask_button"][0], loc["createtask_button"][1]).click()
