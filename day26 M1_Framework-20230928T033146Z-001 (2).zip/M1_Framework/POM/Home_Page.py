from Generic.Read_excel import *

loc = read_locator("Home_Page")

class HomePage:
    def __init__(self, driver):
        self.driver = driver
    def logout_link(self):
        self.driver.find_element(loc["logout_link"][0], loc["logout_link"][1]).click()
    def user_tab(self):
        self.driver.find_element(loc["user_tab"][0], loc["user_tab"][1]).click()
    def timetrack_tab(self):
        self.driver.find_element(loc["timetrack_tab"][0], loc["timetrack_tab"][1]).click()


