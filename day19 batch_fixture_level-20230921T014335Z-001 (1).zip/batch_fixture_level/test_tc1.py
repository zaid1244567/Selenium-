import pytest
from fix import *

pytestmark = pytest.mark.usefixtures("setup")

def test_tc1():
    print("testcsae1")

def test_tc4():
    print("testcsae4")
"""
batch level fixture execution
"""
"""
>pytest -vs
collected 6 items

test_tc1.py::test_tc1 before
testcsae1
PASSED
test_tc1.py::test_tc4 testcsae4
PASSEDend

test_tc2.py::test_tc2 before
testcase2
PASSED
test_tc2.py::test_tc5 testcsae5
PASSEDend

test_tc3.py::test_tc3 before
testcsae3
PASSED
test_tc3.py::test_tc6 testcsae6
PASSEDend
"""