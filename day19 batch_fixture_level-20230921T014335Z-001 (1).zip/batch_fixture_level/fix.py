import pytest


@pytest.fixture(scope="module")
def setup():
    print("before")
    yield
    print("end")