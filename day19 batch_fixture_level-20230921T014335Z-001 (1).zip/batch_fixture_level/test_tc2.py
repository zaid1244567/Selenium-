import pytest
from fix import *

pytestmark = pytest.mark.usefixtures("setup")

def test_tc2():
    print("testcase2")

def test_tc5():
    print("testcsae5")