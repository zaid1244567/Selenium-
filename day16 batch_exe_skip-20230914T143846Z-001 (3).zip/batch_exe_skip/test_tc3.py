import pytest

pytestmark = pytest.mark.xfail(reason="still in progress")

def test_tc3():
    print("testcsae3")

def test_tc6():
    print("testcsae6")
