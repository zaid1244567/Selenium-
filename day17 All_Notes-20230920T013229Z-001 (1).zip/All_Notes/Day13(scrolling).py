from selenium.webdriver import Chrome
from time import sleep
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains

"""
scrolling a webpage:
********************
"""
"""
*to scroll in a webpage we use below methods,
    -->driver.execute_script("window.scrollBy(x, y))
        the above method is for scroll down in a webpage.
    -->driver.execute_script("window.scrollTo(x, y))
        the above method is for scroll up in a webpage.
*if we want to scroll to a particular element in a webpage then find the element x and y axis by using "location"
property and specify that x and y axix.
"""

#ws to scroll down in bigbasket
"""
driver = Chrome()
driver.get("https://www.bigbasket.com/")
driver.maximize_window()
driver.execute_script("window.scrollBy(0, 700)")
"""

#ws to scroll down to why medplus mart in medplsu.com
"""
driver = Chrome()
driver.get("https://www.medplusmart.com/")
driver.maximize_window()
sleep(5)
ele = driver.find_element("xpath", "//h6[.='Why MedPlusMart']")
loc = ele.location
driver.execute_script(f"window.scrollBy({loc['x']}, {loc['y']})")
"""

#ws to scroll down to why medplus mart and scroll up to topoffers in medplsu.com
"""
driver = Chrome()
driver.get("https://www.medplusmart.com/")
driver.maximize_window()
sleep(3)
ele = driver.find_element("xpath", "//h6[.='Why MedPlusMart']")
loc = ele.location
driver.execute_script(f"window.scrollBy({loc['x']}, {loc['y']})")
sleep(3)
ele1 = driver.find_element("xpath", "//h5[.='Top Offers']")
lo = ele1.location
driver.execute_script(f"window.scrollTo({lo['x']}, {lo['y']})")
"""
###################################################################################################################
"""
keyboard actions:
*****************
*to handle keyboard actions for a web-element we use 'keys' module and we should import from below
    from selenium.webdriver.common.keys import Keys
*to perform any keyboard actions we use send_keys() method of web-element.
    element.send_keys(keys.ENTER)
"""

#ws to click on forgot password link iwthout using click() method
"""
driver = Chrome()
driver.get("https://www.facebook.com/")
sleep(2)
link = driver.find_element("xpath", "//a[.='Forgotten password?']")
link.send_keys(Keys.ENTER)
"""

#ws to copy and paste user to password field
"""
driver = Chrome()
driver.get("https://www.facebook.com/")
sleep(2)
un = driver.find_element("id", "email")
un.send_keys("automationuser")
un.send_keys(Keys.CONTROL+"a")
un.send_keys(Keys.CONTROL+"c")
pw = driver.find_element("id", "pass")
pw.send_keys(Keys.CONTROL+"v")
btn = driver.find_element("name", "login")
btn.send_keys(Keys.ENTER)
"""

#ws to backspace 4 times in username field
"""
driver = Chrome()
driver.get("https://www.facebook.com/")
sleep(2)
un = driver.find_element("id", "email")
un.send_keys("automationuser")
for i in range(4):
    un.send_keys(Keys.BACKSPACE)
    sleep(1)
"""

#by using actions chain class handling keyboard cations
"""
driver = Chrome()
driver.get("https://www.facebook.com/")
driver.maximize_window()
sleep(2)
a = ActionChains(driver)
a.key_down(Keys.CONTROL).perform()
a.send_keys("A").perform()
a.key_up(Keys.CONTROL).perform()
a.send_keys("A").perform()
"""
























