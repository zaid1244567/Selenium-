class RegisterPage:
    def gender_radio(self, gender):
        if gender.lower()=="male":
            driver.find_element("xpath", "//input[@value='M']")
        elif gender.lower()=="female":
            driver.find_element("xpath", "//input[@value='F']")
        else:
            print("invalid gender selection")

    def firstname(self, data):
        driver.find_element("id", "FirstName").send_keys(data)

    def lastname(self, data):
        driver.find_element("id", "LastName").send_keys(data)

    def email(self, data):
        driver.find_element("id", "Email").send_keys(data)

    def password(self, data):
        driver.find_element("id", "Password").send_keys(data)

    def confirm_password(self, data):
        driver.find_element("id", "ConfirmPassword").send_keys(data)

    def register_button(self):
        driver.find_element("name", "register-button").click()





