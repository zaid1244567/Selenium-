import pytest
from selenium.webdriver import Chrome

@pytest.fixture
def launch():
    driver = Chrome()
    driver.get("https://demowebshop.tricentis.com/")
    yield
    driver.close()
    
