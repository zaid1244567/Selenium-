class HomePage:
    def register_link(self):
        driver.find_element("xpath", "//a[.='Register']").click()

    def login_link(self):
        driver.find_element("xpath", "//a[.='Log in']").click()




