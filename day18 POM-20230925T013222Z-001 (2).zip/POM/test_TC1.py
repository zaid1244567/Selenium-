from Home_Page import *
from Register_Page import  *

def test_TC1(launch):
    h = HomePage()
    h.register_link()
    r = RegisterPage()
    r.gender_radio("Male")
    r.firstname("demo")
    r.lastname("automation")
    r.email("demoautomation@gmail.com")
    r.password("demo@123")
    r.confirm_password("demo@123")
    r.register_button()
