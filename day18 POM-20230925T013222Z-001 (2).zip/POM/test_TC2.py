from Home_Page import *
from Login_Page import *

def test_TC2(launch):
    h = HomePage()
    h.login_link()
    l = LoginPage()
    l.email("demoautomation@gmail.com")
    l.password("demo@123")
    l.login_button()