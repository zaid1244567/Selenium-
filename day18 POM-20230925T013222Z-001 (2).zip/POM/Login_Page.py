class LoginPage:
    def email(self, data):
        driver.find_element("name", "Email").send_keys(data)

    def password(self, data):
        driver.find_element("name", "Password").send_keys(data)

    def login_button(self):
        driver.find_element("xpath", "//input[@value='Log in']").click()