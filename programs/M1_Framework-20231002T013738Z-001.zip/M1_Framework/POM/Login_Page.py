from Generic.Reading_Json import *
from Generic.Log_File import *

loc = read_json_locator()

class LoginPage:
    def __init__(self, driver):
        self.driver = driver
    def username(self, data):
        logg("info", "entering username")
        self.driver.find_element(*loc["login_page"]["username"]).send_keys(data)
    def password(self, data):
        logg("info", "entering password")
        self.driver.find_element(*loc["login_page"]["password"]).send_keys(data)
    def login_button(self):
        logg("info", "clicking login button")
        self.driver.find_element(*loc["login_page"]["login_button"]).click()

