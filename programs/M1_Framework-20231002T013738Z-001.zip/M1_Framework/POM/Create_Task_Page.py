from selenium.webdriver.support.select import Select
from Generic.Log_File import logg
from Generic.Read_excel import *

loc = read_locator("Create_Task_Page")

class CreateTaskPage:
    def __init__(self, driver):
        self.driver = driver
    def select_customer(self):
        logg("info", "select new customer option from drop down")
        dd = self.driver.find_element("name", "customerId")
        s = Select(dd)
        s.select_by_visible_text("-- new customer --")
    def customer_name(self, data):
        logg("info", "entering customer name")
        self.driver.find_element(*loc["customer_name"]).send_keys(data)
    def project_name(self, data):
        logg("info", "entering project name")
        self.driver.find_element(*loc["project_name"]).send_keys(data)
    def task_name(self, data):
        logg("info", "entering task name")
        self.driver.find_element(*loc["task_name"]).send_keys(data)
    def createtask_button(self):
        ids = self.driver.window_handles
        logg("info", "clicking create task button")
        self.driver.find_element(*loc["createtask_button"]).click()
        self.driver.switch_to.window(ids[0])
        logg("info", "switching back to parent tab")






