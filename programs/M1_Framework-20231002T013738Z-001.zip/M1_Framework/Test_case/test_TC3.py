from Generic.Verify_Title import verify_title
from POM.Home_Page import HomePage
from POM.Login_Page import LoginPage
from POM.Time_Track_Page import *
from POM.Create_Task_Page import *
from Generic.verify_text import *

def test_TC3(launch):
    driver = launch
    verify_title(driver, "actiTIME - Login")
    l = LoginPage(driver)
    l.username("admin")
    l.password("manager")
    l.login_button()
    verify_title(driver, "actiTIME - Enter Time-Track")
    h = HomePage(driver)
    h.timetrack_tab()
    verify_title(driver, "actiTIME - Enter Time-Track")
    t = TimeTrackPage(driver)
    t.select_user("batch, morning (morningbatch)")
    t.new_link()
    c = CreateTaskPage(driver)
    c.select_customer()
    c.customer_name("selenium")
    c.project_name("automation")
    c.task_name("testscript")
    c.createtask_button()
    verifytext(driver, "testscript")
    h.logout_link()
    l.username("morningbatch")
    l.password("morning@123")
    l.login_button()
    verify_title(driver, "actiTIME - Enter Time-Track")
    verifytext(driver, "testscript")
    t.enter_time(9)
    t.save_changes()
    h.logout_link()
    l.username("admin")
    l.password("manager")
    l.login_button()
    verify_title(driver, "actiTIME - Enter Time-Track")
    t.select_user("batch, morning (morningbatch)")
    h.logout_link()

















