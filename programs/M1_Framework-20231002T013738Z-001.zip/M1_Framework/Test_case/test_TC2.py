from Generic.Verify_Title import verify_title
from POM.Login_Page import *
from POM.Home_Page import *
from POM.User_list_Page import *
from Generic.verify_text import *

def test_Tc2(launch):
    driver = launch
    verify_title(driver, "actiTIME - Login")
    l = LoginPage(driver)
    l.username("admin")
    l.password("manager")
    l.login_button()
    verify_title(driver, "actiTIME - Enter Time-Track")
    h = HomePage(driver)
    h.user_tab()
    verify_title(driver, "actiTIME - User List")
    u = UserListPage(driver)
    u.user_button()
    verifytext(driver, "Create New User")
    u.firstname("morning")
    u.lastname("batch")
    u.email("morning@gmail.com")
    u.username("morningbatch")
    u.password("morning@123")
    u.retype_password("morning@123")
    u.create_user_button()
    verifytext(driver, "batch, morning (morningbatch)")
    h.logout_link()
    l.username("morningbatch")
    l.password("morning@123")
    l.login_button()
    verify_title(driver, "actiTIME - Enter Time-Track")
    h.logout_link()







