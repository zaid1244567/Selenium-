import pytest
from selenium.webdriver import Chrome
from Generic.Log_File import *

@pytest.fixture
def launch():
    driver = Chrome(executable_path="../Drivers/chromedriver.exe")
    logg("info", "launching browser")
    driver.get("http://localhost/")
    logg("info", "entering URL")
    driver.maximize_window()
    yield driver
    driver.close()
    logg("info", "closing browser")

