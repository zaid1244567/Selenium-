import pytest

pytestmark = pytest.mark.imp

def test_tc3():
    print("testcsae3")

def test_tc6():
    print("testcsae6")
