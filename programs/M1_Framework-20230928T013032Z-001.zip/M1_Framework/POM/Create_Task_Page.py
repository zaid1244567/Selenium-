from selenium.webdriver.support.select import Select

class CreateTaskPage:
    def __init__(self, driver):
        self.driver = driver
    def select_customer(self):
        dd = self.driver.find_element("name", "customerId")
        s = Select(dd)
        s.select_by_visible_text("-- new customer --")
    def customer_name(self, data):
        self.driver.find_element("name", "customerName").send_keys(data)
    def project_name(self, data):
        self.driver.find_element("name", "projectName").send_keys(data)
    def task_name(self, data):
        self.driver.find_element("id", "task[0].name").send_keys(data)
    def createtask_button(self):
        self.driver.find_element("xpath", "//input[@value='Create Tasks']").click()
