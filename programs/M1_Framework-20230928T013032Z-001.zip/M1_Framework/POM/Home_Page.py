class HomePage:
    def __init__(self, driver):
        self.driver = driver
    def logout_link(self):
        self.driver.find_element("class", "logout").click()
    def user_tab(self):
        self.driver.find_element("xpath", "//a[@class='content users']").click()
    def timetrack_tab(self):
        self.driver.find_element("xpath", "//div[.='Time-Track']").click()


