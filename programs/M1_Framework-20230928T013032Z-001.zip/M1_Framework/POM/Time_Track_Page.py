class TimeTrackPage:
    def __init__(self, driver):
        self.driver = driver
    def select_user(self, user):
        self.driver.find_element("xpath", "//img[@id='ext-gen7']").click()
        self.driver.find_element("xpath", f"//div[.='{user}']").click()
    def new_link(self):
        self.driver.find_element("xpath", "//a[.='New']").click()
        ids = self.driver.window_handles
        self.driver.switch_to.window(ids[1])





