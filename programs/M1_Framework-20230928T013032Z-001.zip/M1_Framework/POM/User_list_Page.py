class UserListPage:
    def __init__(self, driver):
        self.driver = driver
    def user_button(self):
        self.driver.find_element("xpath", "//span[.='User']").click()
    def firstname(self, data):
        self.driver.find_element("name", "firstName").send_keys(data)
    def lastname(self, data):
        self.driver.find_element("id", "userDataLightBox_lastNameField").send_keys(data)
    def email(self, data):
        self.driver.find_element("name", "email").send_keys(data)
    def username(self, data):
        self.driver.find_element("name", "username").send_keys(data)
    def password(self, data):
        self.driver.find_element("name", "password").send_keys(data)
    def retype_password(self, data):
        self.driver.find_element("name", "passwordCopy").send_keys(data)
    def create_user_button(self):
        self.driver.find_element("xpath", "//div[.='Create User']").click()







