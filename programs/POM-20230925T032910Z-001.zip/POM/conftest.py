import pytest
from selenium.webdriver import Chrome

@pytest.fixture
def launch():
    driver = Chrome()
    driver.get("https://demowebshop.tricentis.com/")
    yield driver
    driver.close()
    
"""
*conftest is a special file, in pytest which we can store only fixtures.
*conftest is like a repository.
*file name should be conftest.py
*always fixture name should be the 1st argument in each test function.
*main advantage of conftest file is without writing import stmt  in test_case module file, we can 
directly access.
*because when we write fixture name always 1st it will go and search inside conftest file and execute.
"""
#############################################################################################################################################
"""
how to generate html report:
****************************
*to generate html report of test case execution we should install "pytest-html" module/plugin.
*file --> settings -> click on project -> click on python interpreter --> click on plus -->
search for pytest-html --> click on install package --> once after installing "successful message will appear"

*to generate html report and it will store in current location,
    >>pytest -rp filename.py --html="report-name.html"
*to generate html report on batch execution,
    >>pytest -rp --html="report-name.html"
(in above both execution will store in current location)

*command to generate html file and store in particular location/folder,
    >>pytest -rp --html="../folder-name/report-name.html"

note:
-----
*insted of -rp(report portal) we can write -vs, but -vs wont print message in report, so when ever
we are generating html report better to write -rp.
"""
