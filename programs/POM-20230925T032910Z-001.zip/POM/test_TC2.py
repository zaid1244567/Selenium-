from Home_Page import *
from Login_Page import *

def test_TC2(launch):
    driver = launch
    h = HomePage(driver)
    h.login_link()
    l = LoginPage(driver)
    l.email("demoautomation@gmail.com")
    l.password("demo@123")
    l.login_button()