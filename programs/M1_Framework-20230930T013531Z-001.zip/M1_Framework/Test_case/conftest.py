import pytest
from selenium.webdriver import Chrome

@pytest.fixture
def launch():
    driver = Chrome(executable_path="../Drivers/chromedriver.exe")
    driver.get("http://localhost/")
    driver.maximize_window()
    yield driver
    driver.close()


