from Generic.Reading_Json import *
from time import sleep

loc = read_json_locator()

class TimeTrackPage:
    def __init__(self, driver):
        self.driver = driver
    def select_user(self, user):
        self.driver.find_element(*loc["Time_Track"]["select_user"]).click()
        self.driver.find_element("xpath", f"//div[.='{user}']").click()
        sleep(4)
    def new_link(self):
        self.driver.find_element(*loc["Time_Track"]["new_link"]).click()
        ids = self.driver.window_handles
        self.driver.switch_to.window(ids[1])





