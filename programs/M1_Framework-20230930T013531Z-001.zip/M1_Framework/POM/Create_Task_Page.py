from selenium.webdriver.support.select import Select
from Generic.Read_excel import *

loc = read_locator("Create_Task_Page")

class CreateTaskPage:
    def __init__(self, driver):
        self.driver = driver
    def select_customer(self):
        dd = self.driver.find_element("name", "customerId")
        s = Select(dd)
        s.select_by_visible_text("-- new customer --")
    def customer_name(self, data):
        self.driver.find_element(*loc["customer_name"]).send_keys(data)
    def project_name(self, data):
        self.driver.find_element(*loc["project_name"]).send_keys(data)
    def task_name(self, data):
        self.driver.find_element(*loc["task_name"]).send_keys(data)
    def createtask_button(self):
        pid = self.driver.current_window_handle
        self.driver.find_element(*loc["createtask_button"]).click()
        self.driver.switch_to.window(pid)






